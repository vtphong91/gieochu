---
tags:
  - spec
  - payment
  - billing
  - status/living
date: 2026-09-26
updated: 2026-10-27
author: System Architect
---

# 📐 Đặc Tả: Thanh Toán & Billing (Payment & Billing Specs)

## 1. Tổng Quan: Hai Hệ Thống Thanh Toán Tách Biệt

Gieo Chữ có **hai** hệ thống thanh toán dùng chung code (`packages/payments`) nhưng **không bao giờ** chung
bảng, secret, hay route (CLAUDE.md, ranh giới layer):

| | Platform Billing | Tenant Billing |
| :--- | :--- | :--- |
| **Ai trả tiền cho ai** | Tenant trả **Gieo Chữ** để mua/gia hạn gói dịch vụ | Customer trả **Tenant** để mua tài liệu |
| **`PaymentScope`** | `{kind: 'PLATFORM'}` | `{kind: 'TENANT', tenantId}` |
| **Bảng cấu hình** | `PlatformPaymentConfig` (L1, 1 dòng/provider) | `TenantPaymentConfig` (L2, RLS, `@@unique([tenantId, provider])`) |
| **Bảng giao dịch** | `PlatformPaymentTransaction` | `TenantPaymentTransaction` |
| **Đối tượng thanh toán** | `SubscriptionInvoice` | `Order` |
| **Route webhook** | `POST /api/webhooks/platform/[provider]` | `POST /api/webhooks/tenants/[tenantId]/[provider]` |

Mọi hàm trong `packages/payments` (`createCheckout`, `verifyWebhook`, `parseWebhook`) nhận `PaymentScope` làm
tham số đầu — không có "chế độ mặc định" ngầm định nào trộn lẫn 2 luồng.

---

## 2. Nhà Cung Cấp Thanh Toán (`PaymentProviderId`)

```prisma
enum PaymentProviderId { MANUAL_QR  SEPAY  MOMO  MOMO_MANUAL }
```

`MOMO_MANUAL` thêm ở ADR-059 bổ sung lần 3 (migration `20261026150000_adr059_momo_manual` — **đã áp**, Quốc kiểm `prisma migrate status` 2026-10-27), §5J.

- **`MANUAL_QR`**: tự dựng payload VietQR (EMVCo TLV + CRC-16/CCITT-FALSE, `packages/payments/src/vietqr.ts`)
  từ số tài khoản/BIN ngân hàng đã cấu hình — không gọi API bên thứ 3, owner tự đối soát bằng mắt hoặc xác
  nhận thủ công.
- **`SEPAY`**: `authType` là `API_KEY` hoặc `HMAC_SHA256`, có `paymentPrefix` (khớp `Tenant.orderCodePrefix`
  hoặc `"SUB"` cho platform) để đối soát nội dung chuyển khoản. Từ ADR-059 bổ sung lần 2 tiền tố **không khoá**: platform sinh mã hoá
  đơn SePay theo `paymentPrefix`, gian hàng thử cả `paymentPrefix` lẫn `orderCodePrefix` khi đọc webhook — §5H ✅.
- **`MOMO_MANUAL`** (ADR-059 bổ sung lần 3, đã commit `fa29d99`, migration đã áp) ✅ code: ví MoMo cá nhân, khách chuyển tay, người nhận xác nhận tay; không webhook. Dùng cho **cả**
  PLATFORM lẫn TENANT, bật song song được với chuyển khoản ngân hàng. Chi tiết §5J. **`MOMO`** (MoMo API) giữ nguyên cấu hình và code.
- **Loại xác nhận tay** (`MANUAL_CONFIRM_PROVIDERS` / `isManualConfirmProvider`, `packages/payments/src/registry.ts`) ✅: **`MANUAL_QR`, `MOMO_MANUAL`** — dùng chung
  email báo, nút và luật xác nhận tay / xác nhận trễ.
- **`MOMO`**: `partnerCode`/`accessKey`/`secretKey`, môi trường `sandbox`/`production`, dùng `createCheckout`
  redirect (`CheckoutRedirectResult`) thay vì QR tĩnh.

**Mã hoá secret:** `encryptedSecrets` (AES-256-GCM, `encryptSecret`/`decryptSecret`/`maskSecret` —
`packages/core/src/crypto/`, chuyển từ `packages/payments` sang `core` ở ADR-017 để dùng chung được với
storage) — secret **không bao giờ** trả về client, UI chỉ hiện `••••abcd` (CLAUDE.md §7.3).

**Tự tắt khi đổi định danh tài khoản (ADR-013):** khi admin/owner sửa số tài khoản/BIN (hoặc `partnerCode`
MoMo) hay secret, hệ thống tự đặt `isEnabled=false` + xoá `lastVerifiedAt` — phải lưu lại và bật lại chủ động
để xác nhận cấu hình mới. Sửa các trường không ảnh hưởng định danh (tên chủ TK, `authType`...) không kích hoạt
việc này.

---

## 3. Webhook — Xác Thực Trước, Idempotent, Trả 2xx Nhanh (CLAUDE.md §7.4)

```mermaid
sequenceDiagram
    participant P as Provider (SePay/MoMo)
    participant R as Route Handler (/api/webhooks/tenants/[id]/[provider])
    participant DB as webhook_events (idempotency)
    participant J as Job Queue (pg-boss)
    participant O as apps/web/lib/payment-process.ts

    P->>R: POST webhook (chữ ký/HMAC trong header)
    R->>R: verifyWebhook() — so sánh bằng timingSafeEqual, KHÔNG parse nghiệp vụ trước khi xác thực
    alt Provider lạ / config không tồn tại hoặc tắt
        R-->>P: 404 unsupported_provider / not_configured
    else Chữ ký sai
        R-->>P: 401 invalid_signature
    else Body không phải JSON / thiếu trường bắt buộc (ADR-059)
        R-->>P: 400 invalid_body (+ log warn)
    else Chữ ký đúng
        R->>DB: INSERT webhook_events (scope, provider, providerEventId) — unique constraint chặn trùng
        R->>J: enqueuePaymentProcess(...) — KHÔNG xử lý nghiệp vụ nặng trong request
        R-->>P: 200 OK ngay
        Note over R,J: ADR-036 — after() chạy drainQueues ngay sau response (fetch → complete/fail); cron hằng ngày dọn job sót
        J->>O: job "payment.process" — so khớp orderId theo mã tham chiếu
        O->>DB: withTenant(tenantId) — ghi TenantPaymentTransaction (MATCHED/UNMATCHED/MISMATCH_AMOUNT)
        O->>O: markOrderPaid() nếu khớp và đơn còn hiệu lực PENDING (từ ADR-061 không còn cửa sổ trễ 24h)
    end
```

- **`timingSafeEqual`**: so sánh chữ ký/API key trong `packages/payments/src/providers/sepay.ts` và
  `momo.ts` — chống timing attack, không dùng `===` trên chuỗi bí mật.
- **`webhook_events`** (`@@unique([scope, provider, providerEventId])`): cùng một event id từ provider không
  bao giờ được xử lý 2 lần cho cùng scope+provider — ghi qua `withSystemJob` (chưa có tenant session lúc
  webhook thô vừa tới).
- **Ai xử lý job `payment.process` (ADR-036, chưa deploy) ✅:** trên Vercel không có worker thường trực — route webhook tenant gọi
  `scheduleQueueDrain([PAYMENT_PROCESS])` (`apps/web/lib/job-runner.ts`) **sau** khi đã enqueue, bọc `after()` của Next.js: response
  200 trả trước, rồi trong cùng function (`maxDuration = 60`) bộ xử lý lấy job bằng pg-boss `fetch`, gọi `processPaymentEvent`, đánh
  dấu `complete`/`fail`. Lỗi → job còn trong hàng đợi, thử lại sau (`retryDelay` 60 giây + backoff); cron `GET /api/cron/daily` dọn
  phần sót. `scheduleQueueDrain` không bao giờ ném lỗi nên không biến 2xx thành 500. Chi tiết:
  [[02-System-Specs/Background-Jobs-Specs|Background-Jobs-Specs]].
- **Webhook về sau hạn giữ đơn** — từ đợt 1 ADR-061 (2026-10-27, working tree) ✅ code: **không còn cửa sổ trễ 24h**; tiền về khi đơn đã hết hạn → giao dịch ghi
  `MATCHED` nhưng **không** tự fulfil, hiện ở Studio "Giao dịch cần xử lý" với nhãn "Về sau hạn giữ đơn" ([[Order-State-Machine]] §3.1, §3.11). (Trước ADR-061: chỉ
  không fulfil khi trễ hơn 24h — chủ dự án chốt 2026-10-16.)
- **Khoảng lệch đã biết giữa 2 module (ADR-019):** route webhook **Tenant** (M8) làm đúng đặc tả — chỉ xác
  thực + ghi `webhook_events` + đẩy job `payment.process`. Route webhook **Platform** (M3,
  `POST /api/webhooks/platform/[provider]`) xử lý đồng bộ trong request (gọi `markInvoicePaid()` trực tiếp) —
  **chưa được đồng bộ hoá lại** với M8 vì rủi ro sửa một module thanh toán đã ổn định/đã có test xanh ngoài
  phạm vi công việc đang làm; ghi vào `docs/BACKLOG.md`. Từ ADR-059 (B2) vẫn đồng bộ, nhưng **ghi `platform_payment_transactions` trước
  rồi mới gọi `markInvoicePaid`** — §5G ✅.
- **Mã trạng thái (đối chiếu code 2026-10-26) ✅:** cả 2 route: provider ngoài `SEPAY`/`MOMO` → 404 `unsupported_provider`; chưa cấu hình/tắt →
  404 `not_configured`; **chữ ký sai → 401 `invalid_signature`**; body hỏng/thiếu trường (sau khi chữ ký đúng) → **400 `invalid_body`** (ADR-059 bổ sung
  lần 2 — trước đây `TypeError` thành 500); sự kiện trùng → 200 `{ success: true }`. Trang này trước 2026-10-26 ghi "chữ ký sai → 404" — sai, xem
  KB-Audit §41.
- **Kiểm payload SePay** (`parseSepayWebhook`) ✅: body phải là object; bắt buộc `id` (chuỗi/số khác rỗng), `transferType ∈ {in, out}`, `transferAmount`
  số nguyên ≥ 0 (nhận cả chuỗi số), `transactionDate` chuỗi.

---

## 4. `markOrderPaid()` — Điểm Hội Tụ Duy Nhất Của Tenant Billing

Mọi nguồn tiền vào cho `Order` (webhook SePay, IPN MoMo, xác nhận thủ công của owner, đơn 0đ) đều đi qua
**đúng một hàm** `markOrderPaid(tx, orderId, source)` — xem chi tiết máy trạng thái tại
[[Order-State-Machine]]. Đây là nguyên tắc kiến trúc quan trọng nhất của Tenant Billing: không có đường tắt
nào khác ghi `Order.status = PAID`.

---

## 5. Platform Billing — Mô Hình Free Forever + Paid Subscription (ADR-021)

Thay cho mô hình "Trial rồi hết hạn" ban đầu, mọi tenant mới **vào thẳng gói FREE thật, bán được, không bao
giờ hết hạn**:

```mermaid
stateDiagram-v2
    [*] --> ACTIVE_FREE: createTenantForUser() — gán Plan.isFree=true, Subscription.status=ACTIVE
    ACTIVE_FREE --> ACTIVE_PAID: Owner thanh toán hoá đơn nâng cấp (SubscriptionInvoice PAID)
    ACTIVE_PAID --> PAST_DUE: Hết kỳ, chưa thanh toán
    PAST_DUE --> GRACE: Quá hạn PAST_DUE
    GRACE --> ACTIVE_PAID: Thanh toán trong thời gian GRACE
    GRACE --> ACTIVE_FREE: Hết GRACE mà chưa trả — downgrade thẳng về Free (KHÔNG còn READ_ONLY vì lý do billing)
```

- **4 gói:** FREE / CREATOR / PRO / BUSINESS — số liệu (giá, `maxProducts`, `storageMb`, `maxFileMb`,
  `imageStorageMb` (ADR-028, hạn mức ảnh Cloudinary: khởi tạo 100 / 1024 / 2048 / 5120 MB), `features` JSON)
  **customize được qua `/admin/plans`**, không hard-code.
  `Plan.features` là JSON cờ tính năng — business logic (`canUsePlanFeature()`,
  `packages/core/src/billing/feature-gate.ts`) đọc `plan.features`, **không bao giờ** đọc `plan.code` — giữ
  packaging thương mại tách khỏi logic.
- **`TenantStatus.READ_ONLY`** chỉ còn dùng cho moderation/khoá thủ công — **không còn** là hệ quả tự động của
  billing hết hạn (khác thiết kế ban đầu). `LOCKED` (khoá cứng bởi Admin) là trạng thái riêng, không liên quan.
- **`SubscriptionInvoice`** (L1, không RLS) snapshot `amountVnd`/`periodStart`/`periodEnd` từ `Plan` tại thời
  điểm tạo — đổi giá gói sau đó không viết lại hoá đơn đã phát hành.
- **Dedupe hoá đơn PENDING (ADR-013):** bấm "Gia hạn" nhiều lần liên tiếp khi hoá đơn `PENDING` cũ còn hạn sẽ
  tái sử dụng hoá đơn đó, không tạo hoá đơn trùng cho cùng kỳ.
- **Sweep** (`subscription-sweep.ts`) loại trừ Free khỏi mọi truy vấn (`plan: { isFree: false }`). Lịch chạy (ADR-036, chưa
  deploy) ✅: trên Vercel gọi trực tiếp **mỗi ngày một lần** trong HTTP cron `GET /api/cron/daily` (03:00 giờ VN) — chuyển trạng
  thái thuê bao có thể trễ tới ~24h; lịch pg-boss hằng giờ (`0 * * * *`) chỉ còn khi chạy `apps/web/worker.ts` local/server riêng.

### 5A. Hạn mức gói, cờ tính năng, gói năm (ADR-041 A) — đã commit `7f8360b`, deploy ❓

Mức xác minh: ✅ Long đối chiếu working tree 2026-10-17 · 🟡 theo báo cáo · ❓ cần môi trường thật.

- **Ngữ nghĩa hạn mức (ADR-041 A.4 + bổ sung lần 2)** ✅ `packages/core/src/billing/plan-limits.ts`: `0` = **không được phép**
  (0 tài liệu / 0 byte), `PLAN_LIMIT_UNLIMITED = -1` = **không giới hạn**. Áp cho `maxProducts`, `storageMb`, `maxFileMb`,
  `imageStorageMb`. Giá trị âm khác bị `isValidPlanInput` từ chối; lọt vào DB vẫn coi là không được phép.
  - `isWithinPlanLimit`, `canPublishProduct` (`PRODUCT_LIMIT_REACHED` bỏ qua khi `-1`), `getTenantImageQuota` (`-1` → `limitBytes =
    Infinity`) dùng chung nghĩa này ✅.
  - Hiển thị dùng `describePlanLimit` (`NONE`/`UNLIMITED`/`LIMITED`) + `formatPlanLimit` ("Không có" / "Không giới hạn" / "50 tài liệu",
    "500 MB", "5 GB" — ≥ 1.024 MB đổi GB, 1 chữ số thập phân, tính bằng số nguyên) ✅. Billing Studio: `-1` không có thanh % ✅.
  - Form `/admin/plans` cho nhập `min=-1`, gợi ý "0 = không được phép · -1 = không giới hạn" ✅.
  - ❓ Trước ADR-041, Billing coi `limit === 0` là "không giới hạn" — gói trên prod đang để `0` với ý đó sẽ thành "không được phép". Long
    không kiểm dữ liệu `plans` trên DB (kế hoạch §4.1 A3 giao Quốc chạy truy vấn chỉ đọc).
- **Cờ tính năng (ADR-041 A.3)** ✅ `packages/core/src/billing/feature-gate.ts`: `PLAN_FEATURE_KEYS` (6 cờ), `PLAN_FEATURE_LABELS`,
  `IMPLEMENTED_PLAN_FEATURES = []` — chưa cờ nào được chặn theo gói (không có lời gọi `assertPlanFeature`), nên trang Bảng giá **không**
  quảng cáo cờ nào. Quy ước: khi gắn `assertPlanFeature` cho một tính năng thật, thêm khoá vào hằng này trong cùng commit.
- **Gói năm (ADR-041 A.2):** không đổi schema — admin tạo `Plan` `interval = YEAR`; CMS Bảng giá ghép cặp tháng ↔ năm bằng
  `altPlanId`; % tiết kiệm tính từ giá thật (`computeCycleSavingsPercent`, số nguyên, làm tròn xuống) ✅. Không quà tặng tháng, không dùng
  thử, không thẻ Enterprise. Chi tiết: [[02-System-Specs/Pricing-Page-Specs|Pricing-Page-Specs]].
- **Đổi gói giữa kỳ (ADR-041 A.5):** giữ hành vi hiện hành — không tính chênh lệch, kỳ mới nối sau 🟡 (theo ADR, Long chưa đối chiếu lại
  `subscription-billing.ts` đợt này).
- **Billing nhận `?plan={planId}`** ✅ (`studio/[tenantSlug]/billing/page.tsx`): chỉ nhận gói trả phí đang bật; sai/không có → gói hiện tại.

### 5B. Hoàn tiền gói trả phí (ADR-041 B + 2 lần bổ sung) — đã commit `7f8360b`, deploy ❓; migration đã áp 2026-10-17

**Quy tắc** (chủ dự án chốt): trong **7 ngày** kể từ `paidAt`, **chỉ hoá đơn gói PAID đầu tiên** của mỗi tenant, hoàn **100%** (=
`amountVnd` của hoá đơn). Admin **tự chuyển khoản tay** rồi bấm "Đã hoàn" — cổng QR/MoMo không tự hoàn. Tenant đã có **hoá đơn gói PAID
thứ hai** thì **mất quyền** yêu cầu (bổ sung lần 2).

**Dữ liệu** ✅ (migration `20261017100000_adr041_subscription_refunds`): `SubscriptionInvoiceStatus.REFUNDED`, enum
`SubscriptionRefundStatus` (`REQUESTED`/`APPROVED_REFUNDED`/`REJECTED`), bảng **L1** `subscription_refund_requests` (không RLS; `tenantId` và
`invoiceId` đều unique → mỗi tenant tối đa 1 yêu cầu) + 3 CHECK. Chi tiết cột:
[[03-API-Contracts/Database-Schema-Reference|Database-Schema-Reference]] §3.1, §4, §7.

**Điều kiện** ✅ `evaluateRefundEligibility` (`packages/core/src/billing/subscription-refund.ts`, hàm thuần):

| Lý do không đủ điều kiện | Khi nào |
| :-- | :-- |
| `NO_PAID_INVOICE` | Chưa có hoá đơn `PAID`/`REFUNDED` có `paidAt` |
| `ALREADY_REQUESTED` | Tenant đã có yêu cầu (mọi trạng thái) |
| `LATER_PAYMENT` | Có hoá đơn gói `PAID` khác hoá đơn đầu → server ném `AppError` 409 `REFUND_LATER_PAYMENT_EXISTS` |
| `NOT_FIRST_PAYMENT` | Hoá đơn đầu không còn `PAID` (đã `REFUNDED`) |
| `WINDOW_EXPIRED` | `now > paidAt + 7 ngày` (mốc UTC tuyệt đối, không theo ngày lịch) |
| `ZERO_AMOUNT` | Hoá đơn 0đ |

**Luồng** ✅ (`apps/web/lib/subscription-refund.ts`):
1. **Gửi** — Billing Studio, `requestSubscriptionRefundAction` (chỉ `OWNER` qua `requireTenantMember`). Form gửi lý do (tuỳ chọn, ≤ 500) +
   thông tin nhận tiền (ngân hàng theo `bank_bins`, số TK 6–19 chữ số, tên chủ TK chuẩn hoá in hoa không dấu); **không** gửi id hoá
   đơn/số tiền — server tính lại. Thông tin nhận tiền lưu `payoutEncrypted` = JSON mã hoá **AES-256-GCM** bằng `PAYMENT_ENCRYPTION_KEY`.
   Audit `SUBSCRIPTION_REFUND_REQUESTED` (chỉ `invoiceId`, `amountVnd`), email `subscription_refund_requested`.
2. **Admin xem** — `/admin/billing/refunds` (lọc theo trạng thái `?status=`): danh sách chỉ hiện ngân hàng + số TK che `••••1234`; "Xem
   đầy đủ" giải mã theo yêu cầu, audit `SUBSCRIPTION_REFUND_PAYOUT_VIEWED` (chỉ id). Yêu cầu đã xử lý → 409 `REFUND_NOT_PENDING`.
3. **Đã hoàn** — `approveRefundRequest`, một transaction: kiểm lại hoá đơn PAID thứ hai (có → 409, chỉ được Từ chối; UI `approveBlocked`
   ẩn nút); yêu cầu → `APPROVED_REFUNDED` + `payoutEncrypted = NULL`; hoá đơn `PAID → REFUNDED`; thuê bao về **gói Free đang bật** ngay
   (`downgradeToFree`, dùng lại từ sweep — không mất dữ liệu). Điều kiện trạng thái nằm trong câu `UPDATE` (chống bấm 2 lần / 2 admin).
   Thiếu gói Free đang bật → 409 `FREE_PLAN_MISSING`. Audit `SUBSCRIPTION_REFUNDED`, email `subscription_refund_refunded`.
4. **Từ chối** — `rejectRefundRequest`: lý do bắt buộc (≤ 500), `payoutEncrypted = NULL`, gói không đổi. Audit
   `SUBSCRIPTION_REFUND_REJECTED`, email `subscription_refund_rejected` (kèm lý do).
- `markInvoicePaid` bỏ qua hoá đơn `REFUNDED` — webhook/xác nhận tay đến muộn không áp lại hoá đơn đã hoàn ✅.
- Email không chứa số tài khoản; thông tin nhận tiền không vào audit/log ✅.
- Bảng chưa tồn tại (P2021) → `REFUND_UNAVAILABLE` 503 "chức năng hoàn tiền chưa sẵn sàng", không 500 ✅ (`isRefundSchemaMissing`).
- Ranh giới: admin chỉ đọc bảng L1 (tenant, hoá đơn gói) — không đọc đơn/khách của tenant (§7.9) ✅ comment + truy vấn.

**Kiểm dữ liệu thật** 🟡 (Hiếu báo 2026-10-17, gọi lib trực tiếp, email mock): `payoutEncrypted` là ciphertext; reveal có audit chỉ id; Đã
hoàn → hoá đơn `REFUNDED` + Free + payout `NULL`; từ chối cần lý do; hoá đơn thứ hai → 409; quá 7 ngày bị từ chối. **Chưa** kiểm qua UI có
đăng nhập, **chưa** SMTP thật ❓.

### 5C. System Center — lịch sử hoá đơn gói + "Đơn hàng gói dịch vụ" (ADR-056) — working tree, chưa commit ✅ `git status`

Quyết định: [[01-Architecture-Decisions/ADR-041-System-Center-Subscription-Invoices-Bank-Transfer-Qr|ADR-041 KB (≙ ADR-056)]]. Không migration.

- **`/admin/billing/invoices`** — 2 tab bằng `?tab=cho-doi-soat|tat-ca` ✅ (tab lạ → "Chờ đối soát"):
  - *Chờ đối soát*: `listPendingManualInvoices()` như cũ (MANUAL_QR PENDING), nút "Xác nhận đã nhận tiền" → `confirmManualInvoicePayment` (không đổi).
  - *Tất cả*: `listSubscriptionInvoices({ status, provider, page, pageSize })` — mọi trạng thái/cổng, mới nhất trước (`createdAt desc, id desc`),
    `pageSize` kẹp 1–100 (trang dùng 10/20/50/100, mặc định 20). Cột: mã, gian hàng, gói, cổng, số tiền, trạng thái, ngày tạo, hạn thanh toán, ngày thu.
    Nút xác nhận **chỉ** ở dòng `provider = MANUAL_QR` và `status = PENDING`.
- **`/admin/subscriptions`** (menu Kinh doanh → "Đơn hàng", tiêu đề "Đơn hàng gói dịch vụ") ✅ — `listSubscriptions({ planCode, status, page, pageSize })`:
  - Lọc `?plan=` (mã gói; chỉ nhận mã có trong `listPlanFilterOptions()` — mọi gói kể cả đã ngừng bán, xếp theo giá) và `?status=` (6 giá trị
    `SubscriptionStatus`); có `page`/`pageSize`.
  - Sắp xếp `plan.isFree asc` → `currentPeriodEnd asc` → `id asc`: gói trả phí hết hạn sớm nhất lên đầu, **gói miễn phí xếp sau**; cột "Hết hạn" của gói
    miễn phí hiện **"Không thời hạn"** (Free có `currentPeriodEnd = currentPeriodStart` — comment code).
  - "Hoá đơn gần nhất" = hoá đơn mới nhất của tenant (`createdAt desc`, lấy 1). Tên gian hàng link tới `/admin/tenants` (danh sách chung, không trang chi tiết).
- `parseEnumParam(allowed, value)` — query không thuộc danh sách → `undefined` (bỏ lọc), không ném lỗi ✅.
- Nhãn/tông badge dùng chung ở `app/admin/_ui/billing-labels.ts` (`INVOICE_STATUS_LABEL`, `INVOICE_PROVIDER_LABEL`, `SUBSCRIPTION_STATUS_LABEL`, …,
  `formatAdminDateTime`/`formatAdminDate` theo `DISPLAY_TIME_ZONE`) ✅.
- **Ranh giới:** bốn hàm chỉ đọc `subscription_invoices`, `subscriptions`, `plans` + tên/slug gian hàng — không đọc đơn/khách của tenant (§7.9) ✅.
- Kiểm bằng integration test có sẵn (`subscription-billing.test.ts`, thêm assert lọc `PAID`+`SEPAY`, `MANUAL_QR`, `CREATOR`+`ACTIVE`, `latestInvoice`) ✅ đọc test;
  xem UI thật với phiên SYSTEM_ADMIN ❓.

### 5D. Khối chuyển khoản dùng chung `BankTransferPanel` (ADR-056 mục 4) ✅ đọc code

`apps/web/app/_ui/bank-transfer-panel.tsx` (client, thuần trình bày — không tự truy vấn). Dùng ở:
- Studio `/studio/{slug}/billing` — hoá đơn gói đang chờ, `checkoutPayload.kind === "QR"` (PaymentScope PLATFORM); `referenceNoun = "hoá đơn"`.
- Checkout `/{tenantSlug}/checkout/{orderCode}` — đơn PENDING có QR (PaymentScope TENANT); `referenceNoun = "đơn hàng"`; số tiền truyền vào là `order.totalVnd`.

Hành vi:
- **"Tải ảnh QR"** là `<a href={qrImageDataUrl} download="QR-<mã>.png">` — QR là data URL PNG sinh ở server; **không `fetch()`** vì CSP `connect-src` không
  có `data:` ✅ comment code.
- Bảng `dl` các dòng: Ngân hàng (chỉ khi tìm được tên theo BIN — không hiện BIN thô), Số tài khoản, Chủ tài khoản, Số tiền, Nội dung chuyển khoản (= mã đơn/mã hoá
  đơn, nền nhấn + câu nhắc nhập đúng nguyên văn). Mỗi dòng một nút "Sao chép"; **số tiền sao chép là số nguyên trơn** (`String(Math.trunc(amountVnd))`, không
  dấu chấm/"đ"), còn hiển thị dạng `formatVndFull`.
- Kết quả sao chép đọc qua **một** vùng `role="status"` `aria-live="polite"` chung của khối (không phải mỗi dòng một vùng); clipboard lỗi → câu hướng dẫn chép tay.
- Tên ngân hàng (bảng L1 `bank_bins`): checkout gọi `getBankByBin(bin)` (hàm mới trong `lib/tenant-payment.ts`, trả `{ shortName, name } | null`); Studio billing
  tra trong danh sách `banks` đã nạp sẵn ở trang (không gọi `getBankByBin`) ✅.

### 5E. Lưu cấu hình cổng platform — kết quả trả về + form nạp lại (2026-10-24/25) ✅ `git diff`

- `savePlatformProviderConfig(input)` (`lib/platform-payment.ts`) nay trả **`{ isEnabled, autoDisabled }`** (trước: `void`): `isEnabled` là trạng thái thật đã lưu,
  `autoDisabled = identityChanged && input.isEnabled` — admin bật nhưng bị **tự tắt** vì định danh tài khoản/secret đổi (ADR-013).
- 3 Server Action `saveManualQrAction`/`saveSepayAction`/`saveMomoAction` trả `PlatformPaymentActionState.message` khi `autoDisabled`: "Đã lưu. Phương thức đang
  tắt vì thông tin tài khoản vừa thay đổi — bật lại và bấm Lưu thêm một lần để xác nhận."; không có thì form hiện "Đã lưu.".
- Ba form (`manual-qr-form.tsx`, `sepay-form.tsx`, `momo-form.tsx`) đặt `key` theo dữ liệu đã lưu (`JSON.stringify(initial)`; MoMo bỏ `lastVerifiedAt` khỏi key
  để "Kiểm tra kết nối" không xoá chữ đang gõ) → form dựng lại khớp DB sau mỗi lần lưu (React 19 reset form nhưng `<select defaultValue>`/Toggle không theo).
- Điểm đọc cấu hình cổng platform mới `getPlatformPaymentConfigRow(provider)` — dùng ở `createRenewalInvoice` và webhook `POST /api/webhooks/platform/[provider]`
  (thay `findUnique` trực tiếp); tách ra để integration test mock (xem
  [[04-Operations-Runbooks/Publish-And-Rollback-Runbook|Publish-And-Rollback-Runbook]] §2.2.1).

### 5F. Hoá đơn gói chờ đối soát: email báo admin + xác nhận trễ hoá đơn EXPIRED (ADR-059 B1 + bổ sung) — đã commit `fa29d99` ✅ đọc code

Quyết định: [[01-Architecture-Decisions/ADR-044-Beta-Payments-Manual-Confirm-Emails-Sepay|ADR-044 KB (≙ ADR-059)]]. Không migration.

- **Email `invoice_pending_manual`** ✅ (`notifyAdminOfPendingManualInvoice`, `lib/subscription-billing.ts`; template
  `renderInvoiceAwaitingReconciliationEmail` ở `packages/email/src/templates/manual-payment-pending.ts`):
  - Người nhận: **"Email hỗ trợ"** — `getSupportEmail()` (`lib/system-settings.ts`) đọc `system_settings.supportEmail` **mỗi lần gửi** (không cache); trống/lỗi đọc
    → `null` → bỏ qua + `logger.warn`, không lỗi.
  - Chỉ khi `createRenewalInvoice` **vừa tạo** hoá đơn (`created = true`, không phải hoá đơn chờ được dùng lại) **và** cổng là loại xác nhận tay
    (`isManualConfirmProvider` — MANUAL_QR, MOMO_MANUAL) **và** caller truyền `options.scheduleNotification`. Studio billing (`renewSubscriptionAction`)
    truyền `(task) => after(task)`; test/script không truyền → không gửi.
  - Lúc chạy (sau response) đọc lại hoá đơn; đã không còn PENDING / không còn MANUAL_QR → bỏ qua. Nội dung chỉ dữ liệu L1: mã hoá đơn, tên + slug gian hàng,
    tên gói, số tiền, hạn thanh toán (giờ VN), link `/admin/billing/invoices` (§7.9).
  - Có ghi `email_send_log` (không thuộc `TENANT_CUSTOMER_FACING_TYPES`).
- **Xác nhận tay theo trạng thái** (`confirmManualInvoicePayment`) ✅:
  | Hoá đơn (MANUAL_QR / MOMO_MANUAL) | Kết quả |
  | :-- | :-- |
  | PENDING | `markInvoicePaid(source: ADMIN_MANUAL_CONFIRM)` — kỳ đã lưu (như cũ) |
  | EXPIRED | `confirmExpiredManualInvoice` (dưới) |
  | PAID | no-op |
  | VOID / REFUNDED | **409 `INVOICE_NOT_CONFIRMABLE`** |
  | cổng tự đối soát (SEPAY, MOMO) | 400 `NOT_MANUAL_INVOICE` (như cũ) |
- **`confirmExpiredManualInvoice`** ✅ — một transaction: khoá dòng `subscriptions` của gian hàng (`FOR UPDATE`) → đọc lại hoá đơn (PAID/REFUNDED → no-op
  idempotent; không phải EXPIRED + cổng xác nhận tay → `INVOICE_NOT_CONFIRMABLE`) → chặn **`NEWER_INVOICE_EXISTS` 409** nếu có hoá đơn khác của gian hàng
  `createdAt` sau hoá đơn này đang PENDING (kể cả đã quá hạn, chưa sweep) hoặc PAID → áp thanh toán với **kỳ tính lại**
  `computeRenewalPeriod(now, subscription.currentPeriodEnd, plan)`, ghi đè `periodStart/periodEnd` của hoá đơn, `paidAt = now`. Cập nhật hoá đơn có điều
  kiện `status = EXPIRED` → hai admin bấm cùng lúc chỉ một lần gia hạn.
  - `paidAt` = lúc xác nhận nên cửa sổ hoàn tiền 7 ngày (§5B) tính từ lúc xác nhận; vẫn là "hoá đơn PAID đầu tiên" nếu trước đó chưa có hoá đơn PAID 🟡 (theo
    ADR; `evaluateRefundEligibility` không đổi ✅).
  - Audit `SUBSCRIPTION_PAID`, `source: ADMIN_MANUAL_CONFIRM` + `previousInvoiceStatus: "EXPIRED"`, `lateConfirmation: true`, `dueAt`,
    `storedPeriodStart/End` (kỳ cũ), `periodRecomputed: true`, `periodStart/End` (kỳ mới) — [[02-System-Specs/Audit-Log-Specs|Audit-Log-Specs]] §4.
  - UI: nút **"Xác nhận trễ…"** ở dòng cổng xác nhận tay + EXPIRED (tab "Tất cả") — `ExpiredConfirmButton` ✅ code; xem trình duyệt ❓.
- Test: assert thêm trong `subscription-billing.test.ts` (case có sẵn) ✅ đọc `git diff --stat`; chạy xanh 🟡 (Quốc báo). Gửi SMTP thật ❓.

### 5G. Áp hoá đơn nguyên tử, webhook ghi giao dịch trước, tab "Giao dịch cổng" (ADR-059 B2) ✅ `git diff`

- **Khoá chung** `lockSubscriptionRow(tx, tenantId)` = `SELECT … FROM subscriptions WHERE tenantId = … FOR UPDATE` (bảng L1). Dùng ở `createRenewalInvoice`,
  `markInvoicePaid`, `confirmExpiredManualInvoice`, `confirmInvoiceFromPlatformTransaction`.
- **`createRenewalInvoice`** — checkout (có thể gọi API cổng) tạo **trước** transaction để không giữ khoá qua mạng; rồi trong transaction có khoá: còn hoá đơn
  PENDING chưa quá hạn → trả hoá đơn đó (`created = false`, bỏ checkout vừa tạo); không thì đọc lại thuê bao dưới khoá, tính kỳ, tạo hoá đơn. Hai lần tạo song song
  không sinh 2 hoá đơn (thay cho dedupe chỉ-đọc của ADR-013 — vẫn cùng ý nghĩa).
- **`markInvoicePaid`** — chỉ áp hoá đơn **PENDING**; mọi trạng thái khác (PAID, EXPIRED, VOID, REFUNDED) → no-op, không audit. Cập nhật có điều kiện
  `status = PENDING` (`updateMany`), `count = 0` → no-op. Webhook và admin cùng lúc → chỉ 1 lần áp, 1 audit. Hoá đơn EXPIRED **không** đi đường này.
  `InvoicePaidSource` vẫn chỉ `PLATFORM_WEBHOOK | ADMIN_MANUAL_CONFIRM`.
- **Webhook platform** — tìm hoá đơn theo danh sách mã ứng viên (§5H); khớp mã **và** đúng số tiền → `matchedInvoiceId`; ghi `platform_payment_transactions`
  **trước**, rồi mới `markInvoicePaid` nếu hoá đơn PENDING. Áp lỗi giữa chừng → giao dịch vẫn còn (khớp, hoá đơn chưa thanh toán) để admin thấy.
- **Tab "Giao dịch cổng"** `/admin/billing/invoices?tab=giao-dich` (`lib/platform-transactions.ts` — `listPlatformTransactions`, chỉ bảng L1, §7.9). Bảng
  không có cột trạng thái — **suy ra** từ `matchedInvoiceId` + trạng thái hoá đơn, với giao dịch chưa khớp thì từ `rawPayload` (cùng quy tắc mã của webhook):
  | `state` | Nhãn | Khi nào |
  | :-- | :-- | :-- |
  | `APPLIED` | Đã áp | Đã khớp, hoá đơn PAID (hoặc REFUNDED sau đó) |
  | `MATCHED_NOT_APPLIED` | Khớp, chưa áp | Đã khớp, hoá đơn chưa thanh toán (vd hết hạn khi tiền về) |
  | `AMOUNT_MISMATCH` | Sai số tiền | Chưa khớp, có hoá đơn mang mã đọc được (webhook chỉ khớp khi đúng tiền) |
  | `INVOICE_NOT_FOUND` | Không tìm thấy hoá đơn | Có mã đúng tiền tố nhưng không có hoá đơn |
  | `NO_REFERENCE` | Thiếu mã hoá đơn | Nội dung không chứa mã |
  | `NOT_INCOMING` | Không phải tiền vào | SePay `transferType ≠ in` / MoMo `resultCode ≠ 0` |
  - Lọc `?loai=` (SQL): `chua-khop` (`matchedInvoiceId` null) · `khop-chua-ap` · `da-ap`; phân trang `page`/`pageSize` (kẹp 1–100, mặc định 20). Cột phụ:
    `duplicateOfInvoice` (≥ 2 giao dịch khớp cùng hoá đơn — khách trả trùng), `differenceVnd`, `confirmable` (hiện nút xác nhận — §5H).

### 5H. Xác nhận hoá đơn từ giao dịch SePay + tiền tố (ADR-059 B2b) ✅ `git diff`

- **`confirmInvoiceFromPlatformTransaction(transactionId, invoiceCode, actorId)`** (Server Action `confirmInvoiceFromTransactionAction`, `requireRole("SYSTEM_ADMIN")`;
  form chỉ gửi mã hoá đơn, server kiểm lại hết):
  1. Mã rỗng → 400 `INVOICE_CODE_REQUIRED`; không có hoá đơn → 404 `INVOICE_NOT_FOUND`.
  2. Transaction: khoá `subscriptions` + dòng giao dịch (`FOR UPDATE`; không có → 404 `TRANSACTION_NOT_FOUND`). Chỉ giao dịch **SePay tiền vào** (`rawPayload.transferType
     = in`), khác → 400 `TRANSACTION_NOT_USABLE`.
  3. Giao dịch đã gắn hoá đơn khác → 409 `TRANSACTION_ALREADY_USED`; hoá đơn PAID/REFUNDED → 409 `INVOICE_ALREADY_PAID`; không phải PENDING/EXPIRED → 409
     `INVOICE_NOT_CONFIRMABLE`.
  4. **Thiếu tiền** (`txn.amountVnd < invoice.amountVnd`) → 409 `TRANSACTION_UNDERPAID`. Đúng/thừa → tiếp.
  5. Hoá đơn **EXPIRED** (mọi cổng, kể cả SEPAY — **chỉ qua đường này**) → chặn `NEWER_INVOICE_EXISTS` như §5F, áp với kỳ tính lại; PENDING → kỳ đã lưu.
  6. Gắn `matchedInvoiceId` có điều kiện (chưa gắn hoặc gắn đúng hoá đơn này) → mỗi giao dịch dùng một lần.
  7. Audit `SUBSCRIPTION_PAID`, **`source: ADMIN_TRANSACTION_CONFIRM`**, `transactionId`, `transactionProvider`, `receivedAmountVnd`, `amountVnd`, **`differenceVnd`**
     (+ metadata trễ nếu EXPIRED). Phần thừa admin hoàn ngoài hệ thống 🟡.
- **Tiền tố platform:** hoá đơn **SEPAY mới** sinh mã `normalizeInvoiceCodePrefix(paymentPrefix)` + 8 ký tự; prefix hợp lệ = chữ/số 1–10 ký tự sau khi viết hoa, không
  hợp lệ → `SUB` + `logger.warn`. Cổng khác vẫn `SUB`. Mã đã có không đổi. Webhook/tab Giao dịch đọc mã bằng `sepayInvoiceReferenceCandidates(payload, prefix)`: thử
  tiền tố đã cấu hình rồi `SUB`, đúng **8** ký tự (`INVOICE_CODE_SUFFIX_LENGTH`). Lưu cấu hình SePay (`/admin/billing/payment`) luôn kèm câu cảnh báo/nhắc dạng mã;
  đổi tiền tố khi tiền tố cũ khác `SUB` → cảnh báo hoá đơn chờ cũ không còn tự khớp.
- **Tiền tố gian hàng:** **không đổi** cách sinh mã đơn (`orderCodePrefix` + 6 ký tự). Webhook tenant thử cả `paymentPrefix` lẫn `orderCodePrefix`, đúng **6** ký tự
  (`ORDER_CODE_SUFFIX_LENGTH`); job nhận `referenceCandidates` (job cũ chỉ có `reference` vẫn chạy). Lưu cấu hình SePay Studio trả `warning` khi `paymentPrefix` khác
  `orderCodePrefix` (vẫn lưu thành công).
- **Đọc mã** (`extractSepayReferences`, `packages/payments`) — tiền tố được **escape** regex; `code` (SePay tự nhận diện) trước, rồi `content`; `codeLength` cắt đúng độ
  dài nên nội dung bị ngân hàng nối liền (`SUBABCDEFGHNGUYENVANA`) vẫn tách đúng mã. `extractSepayReference` cũ giữ, gọi qua hàm mới.

### 5I. Danh mục email thanh toán do ADR-059 thêm ✅ code

| `type` | Người nhận | Khi nào | Nơi gửi | Ghi `email_send_log` |
| :-- | :-- | :-- | :-- | :-- |
| `order_pending_manual` | Chủ gian hàng | Đơn chọn cổng xác nhận tay — **một lần/đơn** (mốc `ownerManualNotifiedAt`, từ đợt 1 ADR-061); có `methodLabel` | `notifyOwnerOfPendingManualOrder` (`lib/order.ts`), `after()` | Không |
| `invoice_pending_manual` | "Email hỗ trợ" | Hoá đơn gói xác nhận thủ công (QR thủ công / MoMo thủ công) vừa tạo — nội dung có `methodLabel` | `notifyAdminOfPendingManualInvoice` (`lib/subscription-billing.ts`), `after()` | Có |
| `payment_mismatch` | Chủ gian hàng | Giao dịch cổng tiền vào khớp mã đơn, sai số tiền | `notifyOwnerOfPaymentMismatch` (`lib/payment-process.ts`), sau commit trong job | Không |

Chi tiết phía đơn hàng: [[02-System-Specs/Order-State-Machine|Order-State-Machine]] §3.10–§3.11. **Chưa có** email cho giao dịch `UNMATCHED` và cho giao dịch khớp tiền nhưng
về sau hạn giữ đơn ✅ code. Gửi tới hộp thư thật ❓. Email luồng mua của khách (ADR-061/062): §5K.

### 5K. Email luồng mua của khách + mốc chống gửi trùng (ADR-061 Q7/Q9/Q10/Q12, ADR-062 Q1 + bổ sung mục 6) — working tree, chưa commit ✅ đọc code 2026-10-27

Quyết định: [[01-Architecture-Decisions/ADR-046-Customer-Purchase-Flow-Pending-Orders-Notifications|ADR-046 KB (≙ ADR-061)]],
[[01-Architecture-Decisions/ADR-047-Checkout-Layout-Declared-Paid-Guest-Session|ADR-047 KB (≙ ADR-062)]]. Nghiệp vụ đơn: [[02-System-Specs/Order-State-Machine|Order-State-Machine]] §3.12.
Ba loại mới đều thuộc `TENANT_CUSTOMER_FACING_TYPES` (`lib/email-dispatch.ts`) → **không** ghi `email_send_log`; tiêu đề chỉ có mã đơn.

| `type` | Người nhận | Khi nào | Nơi gửi | Chống trùng |
| :-- | :-- | :-- | :-- | :-- |
| `order_payment_customer` | Khách | Chọn hoặc **đổi** phương thức (`initiateOrderCheckout` lên lịch, `after()`) — chỉ khi phương thức hiện tại **khác** lần đã gửi | `notifyCustomerOfPaymentInstructions` (`lib/order-customer.ts`) | Nhận mốc `customerPaymentEmailedProvider`/`customerPaymentEmailedAt`; **tối đa 3 email/đơn** (`MAX_PAYMENT_EMAILS_PER_ORDER`) đếm bằng số dòng audit `ORDER_PAYMENT_EMAIL_SENT` của đơn |
| `order_payment_reminder` | Khách | **1 lần** khi đơn còn chờ, **đã chọn** phương thức, còn ≤ 24 giờ (`PAYMENT_REMINDER_WINDOW_HOURS`) — bước cron `order.payment_reminders` | `runOrderPaymentReminders` (`lib/order-customer.ts`) | Nhận mốc `customerReminderSentAt`; tối đa 500 đơn/lần chạy |
| `guest_activation` | Khách vãng lai (tài khoản tạo lúc mua) | Tạo tài khoản ở trang thanh toán; gửi lại qua resend / quên mật khẩu — "Kích hoạt tài khoản {brand} và đặt mật khẩu", link 7 ngày, một lần | `lib/guest-checkout.ts` (`after()` khi mua; đồng bộ khi gửi lại) | **Có ghi `email_send_log`** (email tài khoản, không thuộc `TENANT_CUSTOMER_FACING_TYPES`); gửi lại 3/email/giờ (rate limit DB) — [[02-System-Specs/Auth-Session-Specs|Auth-Session-Specs]] §9A |
| `order_customer_declared_paid` | Chủ gian hàng | Khách bấm "Tôi đã chuyển khoản" — tiêu đề "Khách báo đã chuyển đơn {mã}", có `methodLabel` + lúc báo + link Studio | `notifyOwnerOfDeclaredPaid` (`lib/order-customer.ts`), `after()` | Nhận mốc `ownerDeclaredPaidNotifiedAt` — một lần/đơn (hoàn tác rồi báo lại không gửi nữa) |

- **Nội dung email khách** (`renderOrderPaymentInstructionsEmail`, `packages/email/src/templates/order-payment.ts`): mã đơn, tên tài liệu, tổng tiền, hạn giữ đơn, phương
  thức (nhãn cho khách — `CUSTOMER_PROVIDER_LABELS`: "Chuyển khoản ngân hàng", "Chuyển khoản (xác nhận tự động)" cho SePay, **"Ví MoMo"** cho `MOMO_MANUAL`; `MOMO` (API) là **"Ví MoMo (tự động)"** (Quốc quyết 2026-10-27, đã có code ✅ working tree)), các
  dòng chuyển tiền dạng chữ lấy từ `checkoutPayload` hiện tại (ngân hàng/số TK/chủ TK/số tiền/nội dung; ví MoMo: ví, số điện thoại, tên chủ, số tiền, nội dung),
  nút về trang thanh toán. **Không nhúng ảnh QR**. Cổng xác nhận tay có câu nhắc bấm "Tôi đã chuyển khoản". Email nhắc đổi tiêu đề "Nhắc thanh toán đơn {mã} — hết hạn …".
- **`order_pending_manual`** nay có `methodLabel` (§5I) và gửi một lần/đơn kể cả khi khách đổi phương thức (`ownerManualNotifiedAt`).
- **`order_paid`** (khách, M8): nút **"Tải tài liệu"** (thay liên kết chữ) trỏ **Thư viện** `APP_URL/account/library?tai-lieu={productId}` (tài liệu đầu tiên của đơn) —
  bắt đăng nhập, không bao giờ link tải trực tiếp/presigned (ADR-061 Q12, ADR-062 Q7). Dưới nút có dòng dán liên kết dự phòng.
- **Email người bán khi thanh toán thành công:** `new_sale` có sẵn (M8), gửi cho mọi cổng kể cả SePay — khớp ADR-061 Q9 ✅ code.
- **6 cột mốc trên `orders`** (migration `20261026180000_adr061_purchase_flow`): `customerDeclaredPaidAt`, `customerPaymentEmailedAt`, `customerPaymentEmailedProvider`,
  `customerReminderSentAt`, `ownerDeclaredPaidNotifiedAt`, `ownerManualNotifiedAt`. Mọi mốc email được **nhận nguyên tử** bằng `updateMany … WHERE <mốc> IS NULL` (hoặc
  khác phương thức) trước khi gửi → không gửi trùng khi `after()`/cron chạy lại. Chi tiết cột: [[03-API-Contracts/Database-Schema-Reference|Database-Schema-Reference]].
- Lưu ý ✅ code: mốc và dòng audit `ORDER_PAYMENT_EMAIL_SENT` được ghi **trước** khi gửi — email gửi lỗi vẫn bị tính vào giới hạn 3 lần và không gửi lại (**Quốc chấp nhận
  2026-10-27** — mục đích của giới hạn là chống spam). Email nhắc
  (`order_payment_reminder`) **không** tính vào giới hạn 3 và không ghi audit.
- Gửi tới hộp thư thật ❓.

### 5J. MoMo cá nhân xác nhận tay — `MOMO_MANUAL` (ADR-059 bổ sung lần 3, B3) — đã commit `fa29d99`; **migration đã áp** (Quốc kiểm `prisma migrate status` — up to date, 2026-10-27) ✅ đọc code

Quyết định: [[01-Architecture-Decisions/ADR-044-Beta-Payments-Manual-Confirm-Emails-Sepay|ADR-044 KB (≙ ADR-059)]] §3.6, §3.7.

> **Bổ sung ADR-059 lần 4 (2026-10-27, chủ dự án chốt; code working tree chưa commit ✅ `git diff`): MoMo thủ công KHÔNG có QR.** Bỏ hẳn ô "Số tài khoản VietQR của ví" và
> hằng `MOMO_VIETQR_BIN`; cấu hình chỉ còn **số điện thoại + tên chủ ví**; checkout luôn `qr: null` (nhánh F1). Runbook kiểm chứng QR
> ([[04-Operations-Runbooks/MoMo-Manual-Verification-Runbook|MoMo-Manual-Verification-Runbook]]) **không còn áp dụng**. Không migration. Các dòng dưới đã sửa theo lần 4.

- **Phạm vi:** provider mới cho **cả PLATFORM** (`/admin/billing/payment`, hoá đơn gói) **lẫn TENANT** (`/studio/{slug}/settings/payments`, đơn tài liệu). Form
  `momo-manual-form.tsx` ở hai nơi, đọc chung `readMomoManualForm` (`apps/web/lib/momo-manual-config.ts`).
- **Cấu hình** (`momoManualProvider.validateConfig`, `packages/payments/src/providers/momo-manual.ts`) — không có secret:
  | Trường | Nhãn form | Luật |
  | :-- | :-- | :-- |
  | `phone` | Số điện thoại MoMo | Chuẩn hoá `0xxxxxxxxx` (nhận `+84`/`84`, bỏ dấu cách/chấm/gạch), đầu số `03/05/07/08/09` |
  | `accountName` | Tên chủ ví | Bỏ dấu, `đ` → `D`, VIẾT HOA, 2–70 ký tự `A–Z0–9` và khoảng trắng |
  | ~~`vietQrAccountNo`~~ | ~~Số tài khoản VietQR của ví (tuỳ chọn)~~ | **Đã bỏ ở lần 4** — form không còn ô này; schema `z.object` mặc định **loại bỏ khoá lạ** nên cấu hình cũ còn `vietQrAccountNo` vẫn hợp lệ, trường đó bị bỏ qua (không cần migration) |
- **Checkout kiểu `WALLET`** (`CheckoutWalletResult`, `packages/payments/src/types.ts`): `{ kind: "WALLET", wallet: "MOMO", phone, accountName, content, amountVnd, qr }`.
  `content` = mã đơn / mã hoá đơn (cùng luật tiền tố như MANUAL_QR). **Từ lần 4: `createCheckout` luôn trả `qr: null`** = phương án F1 (chỉ thông tin + nút sao chép);
  trường `qr` **giữ trong kiểu** `CheckoutWalletResult` để payload cũ đã lưu trên đơn/hoá đơn vẫn đúng kiểu (giao diện vẫn vẽ QR nếu một payload cũ có `qr` ✅ code —
  KB-Audit §46). Lần 3 từng sinh VietQR với BIN `970454` khi có `vietQrAccountNo` — đã bỏ. `CheckoutResult` nay là `CheckoutQrResult | CheckoutRedirectResult | CheckoutWalletResult`.
- **Giao diện:** `WalletTransferPanel` (`apps/web/app/_ui/wallet-transfer-panel.tsx`) dùng ở checkout đơn tài liệu và trang gói Studio: các ô chỉ đọc có nút sao chép
  (Số điện thoại MoMo, Tên chủ ví, Số tiền, Nội dung chuyển khoản), **không có ảnh QR** (lần 4), "Chuyển khoản sau" (link), "Tôi đã chuyển khoản" chỉ hiện lời
  nhắn tại chỗ — **không** đổi trạng thái đơn. Markup tối thiểu, Phong hoàn thiện sau 🟡 (comment code). Nhãn cổng (chủ dự án chốt 2026-10-27, working tree ✅ grep):
  **"MoMo (thủ công)"** ở Studio, System Center và email `payment_mismatch`/admin (email người bán `order_pending_manual` + "khách báo đã chuyển" giữ `methodLabel` dạng câu
  mô tả — Quốc chấp nhận 2026-10-27); **"Ví MoMo"** cho khách (checkout, email khách) — MoMo API cho khách là **"Ví MoMo (tự động)"** (đã có code ✅, `CUSTOMER_PROVIDER_LABELS.MOMO`); **"Ví MoMo (thủ công)"** ở Bảng giá; tiêu đề form
  cấu hình "MoMo cá nhân (xác nhận thủ công)". (Trước đó: "MoMo (chuyển tay)" / "Ví MoMo (chuyển tay)".)
- **Xác nhận:** cùng luật MANUAL_QR — đơn tài liệu: chủ gian hàng xác nhận tay (`canManuallyConfirmOrder`); hoá đơn gói: `confirmManualInvoicePayment` (PENDING) và
  **xác nhận trễ** `confirmExpiredManualInvoice` (EXPIRED — chặn `NEWER_INVOICE_EXISTS`, tính lại kỳ), tab "Chờ đối soát" lọc mọi cổng xác nhận tay
  (`notIn` các cổng tự đối soát) ✅ code.
- **Không webhook:** `verifyWebhook` luôn `false`, `parseWebhook` ném lỗi. Route `/api/webhooks/platform/momo_manual` và `/api/webhooks/tenants/{id}/momo_manual`
  → **404 `unsupported_provider`** (không nằm trong `VALID_PROVIDERS`) ✅ code.
- **Email:** `invoice_pending_manual` (báo admin) truyền `methodLabel` — "chuyển tiền MoMo (xác nhận thủ công)" (trước: "…(xác nhận tay)") hoặc "chuyển khoản QR thủ công" ✅. `order_pending_manual`
  (báo người bán) cũng gửi cho MOMO_MANUAL nhưng **template không có `methodLabel`** — câu chữ vẫn "Khách vừa chọn chuyển khoản…" ✅ code — KB-Audit §43.
- **Tự tắt khi đổi định danh (ADR-013) — chỉ cấu hình platform:** `accountIdentity` (`lib/platform-payment.ts`) với MOMO_MANUAL = `{ phone }` (lần 4; lần 3 gồm cả số TK
  VietQR) → **chỉ đổi số điện thoại** làm cổng **tự tắt**, phải lưu lại lần nữa; đổi tên chủ ví không tự tắt. Cấu hình tenant không có cơ chế tự tắt (như các cổng tenant khác) ✅ code.
- **Trước khi áp migration** (nay đã áp — giữ để hiểu hành vi trên DB khác): DB chưa có giá trị enum → Postgres 22P02; `isMissingEnumValueError` (`lib/db-errors.ts`) bắt ở 2 action lưu cấu hình → báo
  `MOMO_MANUAL_NOT_READY_MESSAGE` ("Hệ thống chưa sẵn sàng cho MoMo cá nhân…"), danh sách hoá đơn lọc `MOMO_MANUAL` coi như rỗng — không 500 ✅ code.
- **MoMo API (`MOMO`)** giữ nguyên cấu hình và code, để trạng thái tắt — không xoá, không tự sửa dữ liệu (thay quyết định "tạm ẩn" ở ADR-059 mục 2) 🟡 ADR.
- **Việc cần làm — Chính sách người bán** 🟡 (ADR-059 lần 3 mục 5): số điện thoại và tên chủ ví MoMo của người bán **công khai ở trang thanh toán** → phải ghi rõ trong
  "Chính sách người bán". **Chưa sửa** văn bản trong CMS (ngoài phạm vi; ghi ở `docs/PLAN.md`).
- **Test:** `pnpm test:count` = **100/100 unit, 66/66 integration** ✅ (Long chạy). Kiểm thật với ví MoMo + app ngân hàng ❓ (runbook).

---

## 6. Nguyên Tắc Bảo Mật Bắt Buộc (CLAUDE.md §7, không đổi theo module)

1. Không tin số tiền/trạng thái từ client — luôn tính lại ở server (`calculatePrice()`, `markOrderPaid`).
2. Secret cổng thanh toán (Platform lẫn Tenant) mã hoá AES-256-GCM trước khi lưu DB — không bao giờ trả về
   client dạng plaintext.
3. Webhook xác thực chữ ký **trước** khi parse nghiệp vụ, so sánh bằng `timingSafeEqual`, idempotent qua
   `webhook_events`, trả 2xx nhanh rồi xử lý nặng trong job.
4. Route Handler ghi dữ liệu kiểm tra header `Origin` (CSRF cho non-Server-Action).

---

## 7. Tài Liệu Tham Chiếu & Liên Kết

* [[Order-State-Machine]] — Vòng đời đơn hàng đứng sau `markOrderPaid` ([Order-State-Machine.md](./Order-State-Machine.md))
* [[Architecture-Overview]] — Ranh giới L1/L2 và RLS ([Architecture-Overview.md](./Architecture-Overview.md))
* [docs/DECISIONS.md](../../docs/DECISIONS.md) — ADR-011 (bảng platform config sớm), ADR-012 (xác minh VietQR/CRC16),
  ADR-013 (dedupe/tự tắt config), ADR-019 (webhook Tenant qua job, khoảng lệch với Platform), ADR-021 (Hybrid
  Monetization), ADR-041 (Bảng giá CMS, hạn mức -1/0, hoàn tiền gói 7 ngày), ADR-056 (lịch sử hoá đơn gói, Đơn hàng gói dịch vụ, khối chuyển khoản, mã giảm giá tạo lại QR),
  ADR-059 (beta: email báo xác nhận tay, xác nhận trễ hoá đơn EXPIRED, giao dịch cổng, tiền tố SePay)
* [[01-Architecture-Decisions/ADR-044-Beta-Payments-Manual-Confirm-Emails-Sepay|ADR-044 KB (≙ ADR-059)]] ([ADR-044-Beta-Payments-Manual-Confirm-Emails-Sepay.md](../01-Architecture-Decisions/ADR-044-Beta-Payments-Manual-Confirm-Emails-Sepay.md)) ·
  [[04-Operations-Runbooks/SePay-Live-Test-Runbook|SePay-Live-Test-Runbook]] ([SePay-Live-Test-Runbook.md](../04-Operations-Runbooks/SePay-Live-Test-Runbook.md))
* [[01-Architecture-Decisions/ADR-041-System-Center-Subscription-Invoices-Bank-Transfer-Qr|ADR-041 KB (≙ ADR-056)]] ([ADR-041-System-Center-Subscription-Invoices-Bank-Transfer-Qr.md](../01-Architecture-Decisions/ADR-041-System-Center-Subscription-Invoices-Bank-Transfer-Qr.md))
* [[02-System-Specs/Pricing-Page-Specs|Pricing-Page-Specs]] — trang Bảng giá + CMS `pricing` ([Pricing-Page-Specs.md](./Pricing-Page-Specs.md))
* [docs/GIEOCHU_HYBRID_MONETIZATION_BILLING_PROPOSAL_V2.md](../../docs/GIEOCHU_HYBRID_MONETIZATION_BILLING_PROPOSAL_V2.md)
* [[02-System-Specs/Background-Jobs-Specs|Background-Jobs-Specs]] — job nền + cron (ADR-036) ([Background-Jobs-Specs.md](./Background-Jobs-Specs.md))
* Mã nguồn: `packages/payments/src/*`, `apps/web/lib/{order,payment-process,platform-payment,platform-transactions,tenant-payment-transactions,subscription-billing,subscription-sweep,subscription-refund,tenant-payment,job-runner,job-handlers}.ts`,
  `packages/email/src/templates/manual-payment-pending.ts`, `apps/web/app/studio/[tenantSlug]/orders/giao-dich/`,
  `apps/web/app/admin/billing/{refunds,invoices,payment}/`, `apps/web/app/admin/subscriptions/`, `apps/web/app/admin/_ui/billing-labels.ts`,
  `apps/web/app/_ui/bank-transfer-panel.tsx`, `apps/web/app/_ui/wallet-transfer-panel.tsx`, `apps/web/lib/momo-manual-config.ts`, `apps/web/lib/db-errors.ts`, `apps/web/app/studio/[tenantSlug]/billing/`,
  `packages/core/src/billing/*`

*Quay lại: [[MOC-Home]] (../00-Index/MOC-Home.md)*
